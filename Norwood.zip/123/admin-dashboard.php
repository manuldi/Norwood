<?php
// Include your database connection file
include 'config.php';

// Fetch the supplier count
$supplierQuery = "SELECT COUNT(*) AS supplier_count FROM tbl_supplier";
$supplierResult = mysqli_query($conn, $supplierQuery);
$supplierData = mysqli_fetch_assoc($supplierResult);
$supplierCount = $supplierData['supplier_count'];

// Similarly, fetch counts for products, employees, and deliveries if needed
$productQuery = "SELECT COUNT(*) AS product_count FROM tbl_product";
$productResult = mysqli_query($conn, $productQuery);
$productData = mysqli_fetch_assoc($productResult);
$productCount = $productData['product_count'];

$employeeQuery = "SELECT COUNT(*) AS employee_count FROM tbl_employee";
$employeeResult = mysqli_query($conn, $employeeQuery);
$employeeData = mysqli_fetch_assoc($employeeResult);
$employeeCount = $employeeData['employee_count'];

// $deliveryQuery = "SELECT COUNT(*) AS delivery_count FROM deliveries";
// $deliveryResult = mysqli_query($conn, $deliveryQuery);
// $deliveryData = mysqli_fetch_assoc($deliveryResult);
// $deliveryCount = $deliveryData['delivery_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        /* Add your existing styles here */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #F5F5DC;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #017143;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 36px;
        }
        .nav {
            width: 250px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        .nav ul {
            list-style-type: none;
            padding: 0;
        }
        .nav ul li {
            padding: 10px;
            text-align: center;
        }
        .nav ul li a {
            color: #fff;
            text-decoration: none;
            display: block;
        }
        .nav ul li a:hover {
            background-color: #017143;
            transition: 0.3s;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .main-content h2 {
            margin-bottom: 30px;
            color: #333;
        }
        .card {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            display: inline-block;
            width: calc(33% - 40px);
            margin-right: 20px;
            text-align: center;
            color: #333;
        }
        .card h3 {
            margin-bottom: 20px;
        }
        .card p {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .card a {
            text-decoration: none;
            color: #017143;
            font-weight: bold;
        }
        .card a:hover {
            color: #014f2a;
        }
    </style>
</head>
<body>
    <header class="header">
        <h1>Admin Dashboard</h1>
    </header>
    <nav class="nav">
        <ul>
            <li><a href="admin-dashboard.php">Dashboard</a></li>
            <li><a href="admin-product.php">Manage Products</a></li>
            <li><a href="supplier.php">Manage Suppliers</a></li>
            <li><a href="employee.php">Manage Employees</a></li>
            <li><a href="delivery.html">Manage Deliveries</a></li>
        </ul>
    </nav>

    <div class="main-content">
        <h2>Dashboard Overview</h2>
        <div class="card">
            <h3>Manage Products</h3>
            <p><?php echo $productCount; ?> Products</p>
            <a href="admin-product.php">Go to Products</a>
        </div>
        <div class="card">
            <h3>Manage Suppliers</h3>
            <p><?php echo $supplierCount; ?> Suppliers</p>
            <a href="supplier.php">Go to Suppliers</a>
        </div>
        <div class="card">
            <h3>Manage Employees</h3>
            <p><?php echo $employeeCount; ?> Employees</p>
            <a href="employee.php">Go to Employees</a>
        </div>
        <!-- <div class="card">
            <h3>Manage Deliveries</h3>
            <p><?php echo $deliveryCount; ?> Deliveries</p>
            <a href="delivery.html">Go to Deliveries</a>
        </div> -->
    </div>
</body>
</html>
