<?php
session_start();
include 'config.php';

// Fetch all orders
$orderResult = mysqli_query($conn, "SELECT o.*, u.fname, u.lname FROM tbl_order o JOIN tbl_user u ON o.userId = u.userId");

// Handle order status update
if (isset($_POST['update_order'])) {
    $orderId = $_POST['order_id'];
    $status = $_POST['status'];
    $deliveryLocation = $_POST['delivery_location'];
    mysqli_query($conn, "UPDATE tbl_order SET status='$status', deliveryLocation='$deliveryLocation' WHERE orderId='$orderId'");

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Handle order deletion
if (isset($_POST['delete_order'])) {
    $orderId = $_POST['order_id'];
    mysqli_query($conn, "DELETE FROM tbl_order WHERE orderId='$orderId'");
    mysqli_query($conn, "DELETE FROM tbl_order_details WHERE orderId='$orderId'");
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Order Management</title>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin_order.css">
    <link rel="icon" type="/image/png" href="images/icon.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Norwood</title>
</head>
<body>
        <header>
            <div class="hi">
         
                <a href="" class="logo"><img src="images/logo1.png" alt="logo" style="width: 120px;"></a>
                <h1>Norwood International</h1>
            </div>


            <ul>
                <li><a href="admin-index.html">Home</a></li>
                <li><a href="admin-product.php">Products</a></li>
                <li><a href="supplier.php">Suppliers</a></li>
                <li><a href="employee.php">Employees</a></li>
                <li><a href="admin_order.php">Orders</a></li>
            </ul>
        </header>

        
        <h2 class="topic">Order Details</h2>
        <p class="info">In the delivery details section, you can review and manage all orders with their details. You can view and edit many information 
        such as IDs of all orders, ordered products, order date, price and order status.Access to this area is limited. Only administrater and team leaders can reach. 
        The changes you make will be approved after they are checked. </p>

    <div class="container">
        <h1>Admin Order Management</h1>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Order Date</th>
                    <th>Delivery Location</th>
                    <th>Total Amount</th>
                    <th>Products</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = mysqli_fetch_assoc($orderResult)): ?>
                    <tr>
                        <td><?php echo $order['orderId']; ?></td>
                        <td><?php echo $order['fname'] . ' ' . $order['lname']; ?></td>
                        <td><?php echo $order['orderDate']; ?></td>
                        <td>
                            <form method="post" style="display:inline-block;">
                                <input type="hidden" name="order_id" value="<?php echo $order['orderId']; ?>">
                                <input type="text" name="delivery_location" value="<?php echo $order['deliveryLocation']; ?>">
                        </td>
                        <td><?php echo $order['totalAmount']; ?></td>
                        <td>
                            <?php
                            $orderId = $order['orderId'];
                            $productResult = mysqli_query($conn, "SELECT p.name, od.quantity FROM tbl_order_details od JOIN tbl_product p ON od.productId = p.id WHERE od.orderId='$orderId'");
                            while ($product = mysqli_fetch_assoc($productResult)) {
                                echo $product['name'] . '<br>';
                            }
                            ?>
                        </td>
                        <td>
                            <?php
                            mysqli_data_seek($productResult, 0);
                            while ($product = mysqli_fetch_assoc($productResult)) {
                                echo $product['quantity'] . '<br>';
                            }
                            ?>
                        </td>
                        <td>
                            <select name="status">
                                <option value="Pending" <?php if ($order['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                <option value="Confirmed" <?php if ($order['status'] == 'Confirmed') echo 'selected'; ?>>Confirmed</option>
                                <option value="Shipped" <?php if ($order['status'] == 'Shipped') echo 'selected'; ?>>Shipped</option>
                                <option value="Delivered" <?php if ($order['status'] == 'Delivered') echo 'selected'; ?>>Delivered</option>
                                <option value="Cancelled" <?php if ($order['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
                            </select>
                        </td>
                        <td>
                                <button type="submit" name="update_order" class="button3">Update</button>
                            </form>
                            <form method="post" style="display:inline-block;">
                                <input type="hidden" name="order_id" value="<?php echo $order['orderId']; ?>">
                                <button type="submit" name="delete_order" class="delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>


    <footer class="footer">
            <div class="social">
                <a href="https://web.whatsapp.com/"><i class="fa-brands fa-whatsapp" style="color: #000000;"></i></a>
                <a href="https://web.facebook.com/?_rdc=1&_rdr"><i class="fa-brands fa-facebook" style="color: #000000;"></i></a>
                <a href="https://web.facebook.com/?_rdc=1&_rdr"><i class="fa-solid fa-envelope" style="color: #000000;"></i></a>                    
            </div>
            <p align="center"> © Copyright Norwood.lk 2023. All rights reserved</p>
            <p align="center"> Established in 2022</p>
            <p align="center"> Privacy Policy | Terms of Service | Contact Us</p>
            <br>
    </footer>
</body>
</html>
