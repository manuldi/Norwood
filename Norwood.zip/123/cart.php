<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }

        h1, h2 {
            text-align: center;
        }

        .product-item {
            border: 1px solid #ddd;
            padding: 10px;
            margin: 10px;
            text-align: center;
        }

        .cart-controls {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .add-to-cart {
            margin-left: 10px;
        }

        .checkout-btn-container {
            text-align: center;
            margin-top: 20px;
        }

        .checkout-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        .checkout-btn:hover {
            background-color: #218838;
        }

    </style>
    <h1>Shopping Cart</h1>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            session_start();
            include 'config.php';
            $totalPrice = 0;
            $userId = $_SESSION['userId'];

            $result = mysqli_query($conn, "SELECT c.*, p.name, p.price FROM tbl_cart c JOIN tbl_product p ON c.productId = p.id WHERE c.userId='$userId'");
            while ($row = mysqli_fetch_assoc($result)) {
                $productTotal = $row['price'] * $row['quantity'];
                $totalPrice += $productTotal;
                echo "<tr>
                        <td>{$row['name']}</td>
                        <td>
                            <form method='post' action='update_cart.php'>
                                <input type='number' name='quantity' value='{$row['quantity']}' min='1'>
                                <input type='hidden' name='product_id' value='{$row['productId']}'>
                                <input type='submit' value='Update'>
                            </form>
                        </td>
                        <td>{$row['price']}</td>
                        <td>{$productTotal}</td>
                        <td>
                            <form method='post' action='remove_from_cart.php'>
                                <input type='hidden' name='product_id' value='{$row['productId']}'>
                                <input type='submit' value='Remove'>
                            </form>
                        </td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
    <h2>Total Price: <?php echo $totalPrice; ?></h2>

    <!-- Next button for checkout -->
    <div class="checkout-btn-container">
        <form action="order.php" method="get">
            <button type="submit" class="checkout-btn">Next: Checkout</button>
        </form>
    </div>
</body>
<script>
document.querySelectorAll('form[action="remove_from_cart.php"]').forEach(form => {
    form.addEventListener('submit', function(event) {
        if (!confirm('Are you sure you want to remove this item from the cart?')) {
            event.preventDefault();
        }
    });
});
</script>
</html>
